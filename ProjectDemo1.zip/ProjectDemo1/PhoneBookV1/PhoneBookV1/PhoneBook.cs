﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Windows.Forms;
using PhoneBookV1.DatabaseRepository;

namespace PhoneBookV1
{
    public partial class PhoneBook : Form
    {
        

        private Connection con { get; set; }
        private DataSet Ds { get; set; }
        private int TempID { get; set; }

        public PhoneBook()
        {
            InitializeComponent();

            DisplayGrid();

            panelInsert.Visible = false;
           
            
        }

       public void DisplayGrid()
        {
            this.contactTableAdapter.Fill(this.contactsDataSet.Contact);
        }

        private void dgvAll_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string temp;
            temp = this.dgvAll.CurrentRow.Cells[0].Value.ToString();
            this.TempID = int.Parse(temp);

            this.LblID.Text = dgvAll.CurrentRow.Cells[0].Value.ToString();
            this.TxtName.Text = dgvAll.CurrentRow.Cells[1].Value.ToString();
            this.TxtNum1.Text = dgvAll.CurrentRow.Cells[2].Value.ToString();
            this.Txtnum2.Text = dgvAll.CurrentRow.Cells[3].Value.ToString();
            this.Txtemail1.Text = dgvAll.CurrentRow.Cells[4].Value.ToString();
            this.Txtemail2.Text = dgvAll.CurrentRow.Cells[5].Value.ToString();
        }

        private void PhoneBook_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'contactsDataSet.Contact' table. You can move, or remove it, as needed.
            this.contactTableAdapter.Fill(this.contactsDataSet.Contact);

        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {

            var repTemp = new ContactRepository();
            
            this.Ds = repTemp.ReturnGridSearch(this.TxtSearch.Text);

            if (this.Ds.Tables[0].Rows.Count == 1)
            {
                this.dgvAll.AutoGenerateColumns = false;
                this.dgvAll.DataSource = this.Ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Invalid Employee Name!");
            }

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            var contemp = new ContactRepository();
            contemp.Delete(TempID);

            DisplayGrid();
        }

        public void clear()
        {
            LblID.Text=TxtSearch.Text = Txtnum2.Text = TxtNum1.Text = TxtName.Text = Txtemail2.Text = Txtemail1.Text = "";
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if(TxtName.Text!=""&& TxtNum1.Text!=""&& Txtnum2.Text!=""&& Txtemail1.Text!=""&&Txtemail2.Text!="")
                {
                var contemp = new ContactRepository();
                contemp.Update(int.Parse(LblID.Text), TxtName.Text, TxtNum1.Text, Txtnum2.Text, Txtemail1.Text, Txtemail2.Text);

                DisplayGrid();
                clear();
            }else{ MessageBox.Show("NO changes ."); }
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            panelInsert.Visible = true;
            panel1.Visible = false;

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (txtNameN.Text != "" && TxtNum.Text != "" && Txtmail.Text != "")
            {
                var contemp = new ContactRepository();
                contemp.Insert(txtNameN.Text, TxtNum.Text, Txtmail.Text);

                panel1.Visible = true;
                panelInsert.Visible = false;
                DisplayGrid();
            }else { MessageBox.Show("Empty"); }
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            DisplayGrid();
        }
    }
   }

