﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace PhoneBookV1.DatabaseRepository
{
    class ContactRepository
    {
        private Connection con { get; set; }
        private DataSet Ds { get; set; }
        
        private int ID { get; set; }
        private string Name { get; set; }
        private string Number1{ get; set; }
        private string Number2 { get; set; }
        private string Email1 { get; set; }
        private string Email2 { get; set; }

        public ContactRepository()
        {
            this.con = new Connection();
        }

        public DataSet Display(string sql = "select * from Contact;")
        {
            this.Ds = this.con.ExecuteQuery(sql);
            return this.Ds;
        }

        public DataSet ReturnGridSearch(string name)
        {
            string sql = "select * from Contact where Name ='" + name + "'";
            this.Ds = this.con.ExecuteQuery(sql);
            return this.Ds;
        }

        public void Delete(int id)
        {
            string sql = "delete from Contact where ID=" + id + "";
            

            try
            {
                this.con.ExecuteUpdateQuery(sql);
                
                MessageBox.Show("Deletation Done.");
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error: " + exc.Message);
            }
        }

        public void Insert(string name,string number1,string email1)
        {


            string sql = @"insert into Contact
                values ('" + name + "','" + number1 + "', '"+"NA"+"','" + email1 + @"'
                , '" + "NA" + "');";

            try
            {
                this.con.ExecuteUpdateQuery(sql);
               
                MessageBox.Show("Insertion Done.");

            }
            catch (Exception exc)
            {
                MessageBox.Show("Error: " + exc.Message);

            }
        }

        public void Update(int id, string name, string number1,string number2 ,string email1,string email2)
        {

            string sql = @"Update Contact
                set Name='" + name + "',Number1='"+number1+"',number2='"+number2+"',Email1='" + email1 + "',Email2= '" + email2 +"' where ID="+id+"";
       
            try
            {
                this.con.ExecuteUpdateQuery(sql);
                MessageBox.Show("Update Successfull.");

            }
            catch (Exception exc)
            {
                MessageBox.Show("Error: " + exc.Message);
            }

        }

    }


}
