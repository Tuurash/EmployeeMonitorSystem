﻿namespace EmployeeManagementSystem.PresentationLayer
{
    partial class ManageSalary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtDefaultSalary = new MetroFramework.Controls.MetroTextBox();
            this.TxtOvertimeMnthly = new MetroFramework.Controls.MetroTextBox();
            this.TxtWorkhrMonthly = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.TxtDailyworkHR = new MetroFramework.Controls.MetroTextBox();
            this.TxtOTcount = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.TxtWholeSal = new MetroFramework.Controls.MetroTextBox();
            this.TxtOTpay = new MetroFramework.Controls.MetroTextBox();
            this.LblID = new MetroFramework.Controls.MetroLabel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.BtnUpdate = new MetroFramework.Controls.MetroButton();
            this.label1 = new System.Windows.Forms.Label();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TxtDefaultSalary
            // 
            // 
            // 
            // 
            this.TxtDefaultSalary.CustomButton.Image = null;
            this.TxtDefaultSalary.CustomButton.Location = new System.Drawing.Point(82, 1);
            this.TxtDefaultSalary.CustomButton.Name = "";
            this.TxtDefaultSalary.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TxtDefaultSalary.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TxtDefaultSalary.CustomButton.TabIndex = 1;
            this.TxtDefaultSalary.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TxtDefaultSalary.CustomButton.UseSelectable = true;
            this.TxtDefaultSalary.CustomButton.Visible = false;
            this.TxtDefaultSalary.Lines = new string[0];
            this.TxtDefaultSalary.Location = new System.Drawing.Point(237, 72);
            this.TxtDefaultSalary.MaxLength = 32767;
            this.TxtDefaultSalary.Name = "TxtDefaultSalary";
            this.TxtDefaultSalary.PasswordChar = '\0';
            this.TxtDefaultSalary.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TxtDefaultSalary.SelectedText = "";
            this.TxtDefaultSalary.SelectionLength = 0;
            this.TxtDefaultSalary.SelectionStart = 0;
            this.TxtDefaultSalary.ShortcutsEnabled = true;
            this.TxtDefaultSalary.Size = new System.Drawing.Size(104, 23);
            this.TxtDefaultSalary.TabIndex = 0;
            this.TxtDefaultSalary.UseSelectable = true;
            this.TxtDefaultSalary.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TxtDefaultSalary.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // TxtOvertimeMnthly
            // 
            // 
            // 
            // 
            this.TxtOvertimeMnthly.CustomButton.Image = null;
            this.TxtOvertimeMnthly.CustomButton.Location = new System.Drawing.Point(82, 1);
            this.TxtOvertimeMnthly.CustomButton.Name = "";
            this.TxtOvertimeMnthly.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TxtOvertimeMnthly.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TxtOvertimeMnthly.CustomButton.TabIndex = 1;
            this.TxtOvertimeMnthly.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TxtOvertimeMnthly.CustomButton.UseSelectable = true;
            this.TxtOvertimeMnthly.CustomButton.Visible = false;
            this.TxtOvertimeMnthly.Lines = new string[0];
            this.TxtOvertimeMnthly.Location = new System.Drawing.Point(237, 351);
            this.TxtOvertimeMnthly.MaxLength = 32767;
            this.TxtOvertimeMnthly.Name = "TxtOvertimeMnthly";
            this.TxtOvertimeMnthly.PasswordChar = '\0';
            this.TxtOvertimeMnthly.ReadOnly = true;
            this.TxtOvertimeMnthly.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TxtOvertimeMnthly.SelectedText = "";
            this.TxtOvertimeMnthly.SelectionLength = 0;
            this.TxtOvertimeMnthly.SelectionStart = 0;
            this.TxtOvertimeMnthly.ShortcutsEnabled = true;
            this.TxtOvertimeMnthly.Size = new System.Drawing.Size(104, 23);
            this.TxtOvertimeMnthly.TabIndex = 1;
            this.TxtOvertimeMnthly.UseSelectable = true;
            this.TxtOvertimeMnthly.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TxtOvertimeMnthly.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // TxtWorkhrMonthly
            // 
            // 
            // 
            // 
            this.TxtWorkhrMonthly.CustomButton.Image = null;
            this.TxtWorkhrMonthly.CustomButton.Location = new System.Drawing.Point(82, 1);
            this.TxtWorkhrMonthly.CustomButton.Name = "";
            this.TxtWorkhrMonthly.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TxtWorkhrMonthly.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TxtWorkhrMonthly.CustomButton.TabIndex = 1;
            this.TxtWorkhrMonthly.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TxtWorkhrMonthly.CustomButton.UseSelectable = true;
            this.TxtWorkhrMonthly.CustomButton.Visible = false;
            this.TxtWorkhrMonthly.Lines = new string[0];
            this.TxtWorkhrMonthly.Location = new System.Drawing.Point(237, 110);
            this.TxtWorkhrMonthly.MaxLength = 32767;
            this.TxtWorkhrMonthly.Name = "TxtWorkhrMonthly";
            this.TxtWorkhrMonthly.PasswordChar = '\0';
            this.TxtWorkhrMonthly.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TxtWorkhrMonthly.SelectedText = "";
            this.TxtWorkhrMonthly.SelectionLength = 0;
            this.TxtWorkhrMonthly.SelectionStart = 0;
            this.TxtWorkhrMonthly.ShortcutsEnabled = true;
            this.TxtWorkhrMonthly.Size = new System.Drawing.Size(104, 23);
            this.TxtWorkhrMonthly.TabIndex = 3;
            this.TxtWorkhrMonthly.UseSelectable = true;
            this.TxtWorkhrMonthly.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TxtWorkhrMonthly.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(84, 72);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(144, 19);
            this.metroLabel1.TabIndex = 4;
            this.metroLabel1.Text = "Monthly Default Salary:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(97, 110);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(131, 19);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "Work Hour(Monthly):";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(73, 351);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(158, 19);
            this.metroLabel4.TabIndex = 7;
            this.metroLabel4.Text = "Monthly OverTime(hours)";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(115, 154);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(109, 19);
            this.metroLabel5.TabIndex = 11;
            this.metroLabel5.Text = "OverTime Count:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(124, 390);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(105, 19);
            this.metroLabel6.TabIndex = 10;
            this.metroLabel6.Text = "Daily Work Hour";
            // 
            // TxtDailyworkHR
            // 
            // 
            // 
            // 
            this.TxtDailyworkHR.CustomButton.Image = null;
            this.TxtDailyworkHR.CustomButton.Location = new System.Drawing.Point(82, 1);
            this.TxtDailyworkHR.CustomButton.Name = "";
            this.TxtDailyworkHR.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TxtDailyworkHR.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TxtDailyworkHR.CustomButton.TabIndex = 1;
            this.TxtDailyworkHR.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TxtDailyworkHR.CustomButton.UseSelectable = true;
            this.TxtDailyworkHR.CustomButton.Visible = false;
            this.TxtDailyworkHR.Lines = new string[0];
            this.TxtDailyworkHR.Location = new System.Drawing.Point(237, 390);
            this.TxtDailyworkHR.MaxLength = 32767;
            this.TxtDailyworkHR.Name = "TxtDailyworkHR";
            this.TxtDailyworkHR.PasswordChar = '\0';
            this.TxtDailyworkHR.ReadOnly = true;
            this.TxtDailyworkHR.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TxtDailyworkHR.SelectedText = "";
            this.TxtDailyworkHR.SelectionLength = 0;
            this.TxtDailyworkHR.SelectionStart = 0;
            this.TxtDailyworkHR.ShortcutsEnabled = true;
            this.TxtDailyworkHR.Size = new System.Drawing.Size(104, 23);
            this.TxtDailyworkHR.TabIndex = 9;
            this.TxtDailyworkHR.UseSelectable = true;
            this.TxtDailyworkHR.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TxtDailyworkHR.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // TxtOTcount
            // 
            // 
            // 
            // 
            this.TxtOTcount.CustomButton.Image = null;
            this.TxtOTcount.CustomButton.Location = new System.Drawing.Point(82, 1);
            this.TxtOTcount.CustomButton.Name = "";
            this.TxtOTcount.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TxtOTcount.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TxtOTcount.CustomButton.TabIndex = 1;
            this.TxtOTcount.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TxtOTcount.CustomButton.UseSelectable = true;
            this.TxtOTcount.CustomButton.Visible = false;
            this.TxtOTcount.Lines = new string[0];
            this.TxtOTcount.Location = new System.Drawing.Point(237, 154);
            this.TxtOTcount.MaxLength = 32767;
            this.TxtOTcount.Name = "TxtOTcount";
            this.TxtOTcount.PasswordChar = '\0';
            this.TxtOTcount.ReadOnly = true;
            this.TxtOTcount.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TxtOTcount.SelectedText = "";
            this.TxtOTcount.SelectionLength = 0;
            this.TxtOTcount.SelectionStart = 0;
            this.TxtOTcount.ShortcutsEnabled = true;
            this.TxtOTcount.Size = new System.Drawing.Size(104, 23);
            this.TxtOTcount.TabIndex = 8;
            this.TxtOTcount.UseSelectable = true;
            this.TxtOTcount.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TxtOTcount.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(115, 250);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(114, 19);
            this.metroLabel7.TabIndex = 15;
            this.metroLabel7.Text = "Overtime Payable";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(63, 201);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(165, 19);
            this.metroLabel8.TabIndex = 14;
            this.metroLabel8.Text = "Salary(Including Overtime)";
            // 
            // TxtWholeSal
            // 
            // 
            // 
            // 
            this.TxtWholeSal.CustomButton.Image = null;
            this.TxtWholeSal.CustomButton.Location = new System.Drawing.Point(82, 1);
            this.TxtWholeSal.CustomButton.Name = "";
            this.TxtWholeSal.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TxtWholeSal.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TxtWholeSal.CustomButton.TabIndex = 1;
            this.TxtWholeSal.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TxtWholeSal.CustomButton.UseSelectable = true;
            this.TxtWholeSal.CustomButton.Visible = false;
            this.TxtWholeSal.Lines = new string[0];
            this.TxtWholeSal.Location = new System.Drawing.Point(237, 201);
            this.TxtWholeSal.MaxLength = 32767;
            this.TxtWholeSal.Name = "TxtWholeSal";
            this.TxtWholeSal.PasswordChar = '\0';
            this.TxtWholeSal.ReadOnly = true;
            this.TxtWholeSal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TxtWholeSal.SelectedText = "";
            this.TxtWholeSal.SelectionLength = 0;
            this.TxtWholeSal.SelectionStart = 0;
            this.TxtWholeSal.ShortcutsEnabled = true;
            this.TxtWholeSal.Size = new System.Drawing.Size(104, 23);
            this.TxtWholeSal.TabIndex = 13;
            this.TxtWholeSal.UseSelectable = true;
            this.TxtWholeSal.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TxtWholeSal.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // TxtOTpay
            // 
            // 
            // 
            // 
            this.TxtOTpay.CustomButton.Image = null;
            this.TxtOTpay.CustomButton.Location = new System.Drawing.Point(82, 1);
            this.TxtOTpay.CustomButton.Name = "";
            this.TxtOTpay.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.TxtOTpay.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.TxtOTpay.CustomButton.TabIndex = 1;
            this.TxtOTpay.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.TxtOTpay.CustomButton.UseSelectable = true;
            this.TxtOTpay.CustomButton.Visible = false;
            this.TxtOTpay.Lines = new string[0];
            this.TxtOTpay.Location = new System.Drawing.Point(237, 250);
            this.TxtOTpay.MaxLength = 32767;
            this.TxtOTpay.Name = "TxtOTpay";
            this.TxtOTpay.PasswordChar = '\0';
            this.TxtOTpay.ReadOnly = true;
            this.TxtOTpay.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TxtOTpay.SelectedText = "";
            this.TxtOTpay.SelectionLength = 0;
            this.TxtOTpay.SelectionStart = 0;
            this.TxtOTpay.ShortcutsEnabled = true;
            this.TxtOTpay.Size = new System.Drawing.Size(104, 23);
            this.TxtOTpay.TabIndex = 12;
            this.TxtOTpay.UseSelectable = true;
            this.TxtOTpay.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.TxtOTpay.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // LblID
            // 
            this.LblID.AutoSize = true;
            this.LblID.Location = new System.Drawing.Point(150, 18);
            this.LblID.Name = "LblID";
            this.LblID.Size = new System.Drawing.Size(79, 19);
            this.LblID.TabIndex = 16;
            this.LblID.Text = "EmployeeID";
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(3, 515);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 18;
            this.metroButton1.Text = "Back";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.label1);
            this.metroPanel1.Controls.Add(this.BtnUpdate);
            this.metroPanel1.Controls.Add(this.metroButton1);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.LblID);
            this.metroPanel1.Controls.Add(this.TxtDefaultSalary);
            this.metroPanel1.Controls.Add(this.metroLabel7);
            this.metroPanel1.Controls.Add(this.TxtOvertimeMnthly);
            this.metroPanel1.Controls.Add(this.metroLabel8);
            this.metroPanel1.Controls.Add(this.TxtWholeSal);
            this.metroPanel1.Controls.Add(this.TxtWorkhrMonthly);
            this.metroPanel1.Controls.Add(this.TxtOTpay);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.TxtDailyworkHR);
            this.metroPanel1.Controls.Add(this.TxtOTcount);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 63);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(503, 541);
            this.metroPanel1.TabIndex = 19;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.Location = new System.Drawing.Point(237, 430);
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.Size = new System.Drawing.Size(104, 82);
            this.BtnUpdate.TabIndex = 19;
            this.BtnUpdate.Text = "Calculate";
            this.BtnUpdate.UseSelectable = true;
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(347, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 24);
            this.label1.TabIndex = 20;
            this.label1.Text = "*";
            // 
            // ManageSalary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 628);
            this.Controls.Add(this.metroPanel1);
            this.Name = "ManageSalary";
            this.Resizable = false;
            this.Text = "ManageSalary";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ManageSalary_FormClosing);
            this.Load += new System.EventHandler(this.ManageSalary_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox TxtDefaultSalary;
        private MetroFramework.Controls.MetroTextBox TxtOvertimeMnthly;
        private MetroFramework.Controls.MetroTextBox TxtWorkhrMonthly;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox TxtDailyworkHR;
        private MetroFramework.Controls.MetroTextBox TxtOTcount;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroTextBox TxtWholeSal;
        private MetroFramework.Controls.MetroTextBox TxtOTpay;
        private MetroFramework.Controls.MetroLabel LblID;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton BtnUpdate;
        private System.Windows.Forms.Label label1;
    }
}